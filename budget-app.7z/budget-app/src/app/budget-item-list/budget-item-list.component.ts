import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Item } from '../shared/models/item.model';
import { MatDialog } from '@angular/material/dialog';
import { EditItemComponent } from '../edit-item/edit-item.component';

@Component({
  selector: 'app-budget-item-list',
  templateUrl: './budget-item-list.component.html',
  styleUrls: ['./budget-item-list.component.scss']
})

export class BudgetItemListComponent implements OnInit {

  @Input() budgetItems: Item[];
  @Output() delete: EventEmitter<Item> = new EventEmitter<Item>();
  @Output() update : EventEmitter<updatedEvent> = new EventEmitter<updatedEvent>();

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
  }
  onDelete(item: Item) {
    this.delete.emit(item);
  }
  onCardClicked(item: Item){
    console.log(item);
    
    const dialogRef=this.dialog.open(EditItemComponent, {width: "580px", data: item});
    dialogRef.afterClosed().subscribe(results=>
      {if(results){
        // this.budgetItems[this.budgetItems.indexOf(item)]=results;
        this.update.emit({old: item, new: results})
      }})
  }

}
export interface updatedEvent{
  old: Item;
  new: Item;
}