import { Component, OnInit, Input, Inject } from '@angular/core';
import { Item } from '../shared/models/item.model';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-item',
  templateUrl: './edit-item.component.html',
  styleUrls: ['./edit-item.component.scss']
})
export class EditItemComponent implements OnInit {

  //@Input() item: Item;
  constructor(public dialogtRef: MatDialogRef<EditItemComponent>, @Inject(MAT_DIALOG_DATA) public item: Item) { }

  ngOnInit() {
  }
  onSubmitted(updateditem: Item){
    this.dialogtRef.close(updateditem);
  }
}
