import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Item } from '../shared/models/item.model';

@Component({
  selector: 'app-add-item-form',
  templateUrl: './add-item-form.component.html',
  styleUrls: ['./add-item-form.component.scss']
})
export class AddItemFormComponent implements OnInit {

  @Input() item: Item;
  @Output() formSubmit: EventEmitter<Item>= new EventEmitter<Item>();
  isNewItem: boolean;
  constructor() { }

  ngOnInit() {
    console.log(this.item);
    if(this.item){
      this.isNewItem=false;
    }
    else{
    this.item= new Item(null, '');
    this.isNewItem=true;
    }
  }
  onSubmit(form: NgForm){
   
    this.formSubmit.emit(form.value);
    form.reset();
  }
}
