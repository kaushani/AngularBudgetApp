export class Item{

constructor(public amount: number,public description: string){};
}