import { Component, OnInit } from '@angular/core';
import { Item } from '../shared/models/item.model';
import { updatedEvent } from '../budget-item-list/budget-item-list.component';

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.scss']
})
export class MainPageComponent implements OnInit {
  budgetItemsArray: Item[]= new Array<Item>();
  total: number=0;
  constructor() { }

  ngOnInit() {
  }
  addItem(item: Item){
    this.budgetItemsArray.push(item);
    this.total=this.total+item.amount;
  }
  deleteItem(item: Item){
    let index= this.budgetItemsArray.indexOf(item);
    this.budgetItemsArray.splice(index, 1);
    this.total= this.total-item.amount;
  }
  updateItem(updatedItem: updatedEvent){
          this.budgetItemsArray[this.budgetItemsArray.indexOf(updatedItem.old)]=updatedItem.new;
          this.total=this.total-updatedItem.old.amount;
          this.total=this.total+updatedItem.new.amount;

  }
}
